from distutils.core import setup

setup(console=['Client.py'])
